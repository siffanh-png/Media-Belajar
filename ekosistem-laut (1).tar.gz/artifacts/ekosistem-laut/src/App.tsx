import { Switch, Route, Router as WouterRouter } from "wouter";
import Landing from "./pages/Landing";
import CaraPenggunaan from "./pages/CaraPenggunaan";
import Home from "./pages/Home";
import CPTujuan from "./pages/CPTujuan";
import Materi from "./pages/Materi";
import VideoEdukasi from "./pages/VideoEdukasi";
import Quiz from "./pages/Quiz";
import Profil from "./pages/Profil";

function NotFound() {
  return (
    <div className="min-h-screen ocean-gradient flex items-center justify-center">
      <div className="text-center text-white">
        <div className="text-6xl mb-4">🌊</div>
        <h1 className="text-2xl font-black mb-2">Halaman tidak ditemukan</h1>
        <a href="/" className="text-cyan-200 underline">Kembali ke Landing</a>
      </div>
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Landing} />
      <Route path="/cara-penggunaan" component={CaraPenggunaan} />
      <Route path="/home" component={Home} />
      <Route path="/cp-tujuan" component={CPTujuan} />
      <Route path="/materi" component={Materi} />
      <Route path="/video" component={VideoEdukasi} />
      <Route path="/quiz" component={Quiz} />
      <Route path="/profil" component={Profil} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
      <Router />
    </WouterRouter>
  );
}
