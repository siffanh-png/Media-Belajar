import { useLocation } from "wouter";

interface NavButtonsProps {
  prevPath?: string;
  nextPath?: string;
  homePath?: string;
  prevLabel?: string;
  nextLabel?: string;
}

export default function NavButtons({ prevPath, nextPath, homePath = "/home", prevLabel = "Kembali", nextLabel = "Lanjut" }: NavButtonsProps) {
  const [, navigate] = useLocation();

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 px-4 pb-4 pt-2"
      style={{ background: "linear-gradient(to top, rgba(0,20,60,0.85) 0%, transparent 100%)" }}>
      <div className="flex justify-center gap-3 max-w-md mx-auto">
        {prevPath && (
          <button
            onClick={() => navigate(prevPath)}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl font-bold text-white shadow-lg transition-all duration-200 active:scale-95 text-sm"
            style={{ background: "linear-gradient(135deg, #0077aa, #005588)", minWidth: 0, flexShrink: 1 }}
          >
            <span>⬅️</span>
            <span className="truncate">{prevLabel}</span>
          </button>
        )}

        {nextPath && (
          <button
            onClick={() => navigate(nextPath)}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl font-bold text-white shadow-lg transition-all duration-200 active:scale-95 text-sm"
            style={{ background: "linear-gradient(135deg, #00cc88, #009966)", minWidth: 0, flexShrink: 1 }}
          >
            <span className="truncate">{nextLabel}</span>
            <span>➡️</span>
          </button>
        )}
      </div>
    </div>
  );
}
