import { useEffect, useState } from "react";

interface Bubble {
  id: number;
  left: number;
  size: number;
  duration: number;
  delay: number;
}

export default function OceanBackground({ dark = false }: { dark?: boolean }) {
  const [bubbles] = useState<Bubble[]>(() =>
    Array.from({ length: 18 }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      size: Math.random() * 20 + 8,
      duration: Math.random() * 8 + 6,
      delay: Math.random() * 8,
    }))
  );

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {/* Fish */}
      <span className="fish-swim" style={{ top: "20%", animationDuration: "12s", animationDelay: "0s" }}>🐠</span>
      <span className="fish-swim" style={{ top: "50%", animationDuration: "16s", animationDelay: "4s", fontSize: "1.4rem" }}>🐡</span>
      <span className="fish-swim-reverse" style={{ top: "35%", animationDuration: "14s", animationDelay: "2s" }}>🐟</span>
      <span className="fish-swim-reverse" style={{ top: "65%", animationDuration: "18s", animationDelay: "6s", fontSize: "1.5rem" }}>🐠</span>
      <span className="turtle-anim" style={{ top: "75%", animationDelay: "3s" }}>🐢</span>

      {/* Bubbles */}
      {bubbles.map(b => (
        <div
          key={b.id}
          className="bubble"
          style={{
            left: `${b.left}%`,
            bottom: "-10px",
            width: `${b.size}px`,
            height: `${b.size}px`,
            animationDuration: `${b.duration}s`,
            animationDelay: `${b.delay}s`,
          }}
        />
      ))}

      {/* Bottom corals/seaweed */}
      <div className="absolute bottom-0 left-0 right-0 flex items-end justify-around pb-0 opacity-40">
        <span className="coral-anim text-4xl" style={{ animationDelay: "0s" }}>🪸</span>
        <span className="coral-anim text-3xl" style={{ animationDelay: "0.5s" }}>🌿</span>
        <span className="coral-anim text-5xl" style={{ animationDelay: "1s" }}>🪸</span>
        <span className="coral-anim text-3xl" style={{ animationDelay: "1.5s" }}>🌿</span>
        <span className="coral-anim text-4xl" style={{ animationDelay: "0.3s" }}>🪸</span>
        <span className="coral-anim text-3xl" style={{ animationDelay: "0.8s" }}>🌿</span>
        <span className="coral-anim text-5xl" style={{ animationDelay: "1.2s" }}>🪸</span>
        <span className="coral-anim text-3xl" style={{ animationDelay: "0.6s" }}>🌿</span>
      </div>
    </div>
  );
}
