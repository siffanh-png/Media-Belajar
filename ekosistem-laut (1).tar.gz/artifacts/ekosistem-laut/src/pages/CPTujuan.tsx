import NavButtons from "../components/NavButtons";

const tujuan = [
  { no: 1, text: "Menjelaskan pengertian ekosistem laut", icon: "🌊" },
  { no: 2, text: "Menyebutkan contoh biota laut", icon: "🐠" },
  { no: 3, text: "Memahami rantai makanan di laut", icon: "🦈" },
  { no: 4, text: "Menjelaskan hubungan antar makhluk hidup di laut", icon: "🐙" },
  { no: 5, text: "Mengetahui cara menjaga kelestarian laut", icon: "🌍" },
];

export default function CPTujuan() {
  return (
    <div className="min-h-screen pb-24 relative overflow-hidden"
      style={{ background: "linear-gradient(180deg, #004d80 0%, #0077aa 40%, #00aacc 100%)" }}>
      {Array.from({ length: 10 }).map((_, i) => (
        <div key={i} className="bubble" style={{
          left: `${Math.random() * 100}%`, bottom: 0,
          width: `${Math.random() * 18 + 6}px`, height: `${Math.random() * 18 + 6}px`,
          animationDuration: `${Math.random() * 8 + 5}s`, animationDelay: `${Math.random() * 6}s`
        }} />
      ))}
      <span className="fish-swim text-2xl md:text-3xl" style={{ top: "12%", animationDuration: "13s" }}>🐟</span>
      <span className="fish-swim-reverse text-xl md:text-2xl" style={{ top: "55%", animationDuration: "16s", animationDelay: "4s" }}>🐠</span>

      <div className="relative z-10 text-center pt-8 sm:pt-10 pb-5 sm:pb-6 px-4">
        <div className="float-anim inline-block text-4xl sm:text-5xl mb-2 sm:mb-3">📚</div>
        <h1 className="text-2xl sm:text-3xl md:text-4xl font-black text-white drop-shadow-lg">CP & Tujuan Pembelajaran</h1>
        <div className="flex items-center justify-center gap-2 mt-3">
          <div className="h-1 w-10 sm:w-12 rounded-full bg-white/40"></div>
          <span className="text-lg sm:text-xl">🌊</span>
          <div className="h-1 w-10 sm:w-12 rounded-full bg-white/40"></div>
        </div>
      </div>

      <div className="relative z-10 max-w-3xl mx-auto px-4 space-y-4 sm:space-y-5">
        {/* Capaian Pembelajaran */}
        <div className="glass-card-white rounded-3xl p-4 sm:p-6 slide-in-up">
          <div className="flex items-center gap-3 mb-3 sm:mb-4">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl flex items-center justify-center text-xl sm:text-2xl flex-shrink-0"
              style={{ background: "linear-gradient(135deg, #0077aa, #00aacc)" }}>🎯</div>
            <h2 className="text-lg sm:text-xl font-black text-gray-800">Capaian Pembelajaran</h2>
          </div>
          <div className="rounded-2xl p-3 sm:p-4" style={{ background: "linear-gradient(135deg, #e0f7ff, #f0fbff)", border: "2px solid #b3e5fc" }}>
            <p className="text-gray-700 leading-relaxed font-semibold text-center italic text-sm sm:text-base">
              "Peserta didik mampu memahami hubungan antar makhluk hidup dan lingkungannya serta menjaga keseimbangan ekosistem."
            </p>
          </div>
          <div className="mt-3 sm:mt-4 flex items-center gap-2 sm:gap-3 flex-wrap">
            <span className="px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full text-xs font-bold text-white" style={{ background: "#0077aa" }}>📚 IPAS</span>
            <span className="px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full text-xs font-bold text-white" style={{ background: "#00aacc" }}>🎓 Kelas V SD</span>
            <span className="px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full text-xs font-bold text-white" style={{ background: "#009977" }}>📋 Kurikulum Merdeka</span>
          </div>
        </div>

        {/* Tujuan Pembelajaran */}
        <div className="glass-card-white rounded-3xl p-4 sm:p-6 slide-in-up" style={{ animationDelay: "0.15s" }}>
          <div className="flex items-center gap-3 mb-3 sm:mb-4">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl flex items-center justify-center text-xl sm:text-2xl flex-shrink-0"
              style={{ background: "linear-gradient(135deg, #00aa77, #00cc88)" }}>✅</div>
            <h2 className="text-lg sm:text-xl font-black text-gray-800">Tujuan Pembelajaran</h2>
          </div>
          <p className="text-gray-500 text-xs sm:text-sm mb-3 sm:mb-4">Setelah menggunakan multimedia pembelajaran, siswa diharapkan mampu:</p>
          <div className="space-y-2 sm:space-y-3">
            {tujuan.map((t, i) => (
              <div key={i}
                className="flex items-center gap-2 sm:gap-3 p-2.5 sm:p-3 rounded-2xl"
                style={{ background: "linear-gradient(135deg, rgba(0,170,204,0.08), rgba(0,200,150,0.08))", border: "1.5px solid rgba(0,170,204,0.2)" }}>
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center text-lg sm:text-xl flex-shrink-0"
                  style={{ background: "linear-gradient(135deg, #006994, #00aacc)" }}>
                  {t.icon}
                </div>
                <div className="flex items-start gap-1.5 sm:gap-2">
                  <span className="font-black text-cyan-700 text-xs sm:text-sm w-4 sm:w-5 flex-shrink-0">{t.no}.</span>
                  <span className="text-gray-700 font-semibold text-xs sm:text-sm leading-relaxed">{t.text}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Identitas Materi */}
        <div className="glass-card-white rounded-3xl p-4 sm:p-5 slide-in-up" style={{ animationDelay: "0.3s" }}>
          <h3 className="font-black text-gray-800 mb-3 flex items-center gap-2 text-sm sm:text-base"><span>📋</span> Identitas Materi</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 sm:gap-3">
            {[
              { label: "Mata Pelajaran", value: "IPAS" },
              { label: "Kelas", value: "V (Lima) SD" },
              { label: "Kurikulum", value: "Kurikulum Merdeka" },
              { label: "Bab", value: "Harmoni dalam Ekosistem" },
              { label: "Materi", value: "Ekosistem Laut" },
              { label: "Target", value: "Siswa Kelas V SD" },
            ].map((item, i) => (
              <div key={i} className="rounded-xl p-2.5 sm:p-3" style={{ background: "linear-gradient(135deg, #e0f7ff, #f0fbff)", border: "1.5px solid #b3e5fc" }}>
                <p className="text-xs text-gray-500 font-semibold leading-tight">{item.label}</p>
                <p className="text-xs sm:text-sm font-black text-gray-800 mt-0.5 leading-tight">{item.value}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="absolute bottom-20 left-0 right-0 flex items-end justify-around opacity-40">
        {["🪸","🌿","🪸","🌿","🪸"].map((c,i) => (
          <span key={i} className="coral-anim text-2xl sm:text-3xl" style={{ animationDelay: `${i * 0.4}s` }}>{c}</span>
        ))}
      </div>

      <NavButtons prevPath="/home" prevLabel="Kembali ke Menu" />
    </div>
  );
}
