import NavButtons from "../components/NavButtons";

const steps = [
  { icon: "⬅️", title: "Tombol Kembali", desc: "Tekan tombol ini untuk kembali ke halaman sebelumnya." },
  { icon: "🏠", title: "Tombol Menu", desc: "Tekan tombol ini untuk kembali ke menu utama kapan saja." },
  { icon: "📖", title: "Pelajari Berurutan", desc: "Pelajari materi secara berurutan dari awal untuk pemahaman terbaik." },
  { icon: "❓", title: "Kerjakan Quiz", desc: "Setelah belajar, kerjakan quiz di akhir untuk uji pemahamanmu!" },
  { icon: "🎥", title: "Tonton Video", desc: "Saksikan video edukasi seru tentang ekosistem laut!" },
  { icon: "👆", title: "Navigasi Materi", desc: "Gunakan tombol Sebelumnya/Berikutnya di dalam materi untuk berpindah subbab." },
];

export default function CaraPenggunaan() {
  return (
    <div className="min-h-screen ocean-gradient relative overflow-hidden pb-24">
      {Array.from({ length: 12 }).map((_, i) => (
        <div key={i} className="bubble" style={{
          left: `${Math.random() * 100}%`, bottom: 0,
          width: `${Math.random() * 20 + 6}px`, height: `${Math.random() * 20 + 6}px`,
          animationDuration: `${Math.random() * 8 + 5}s`, animationDelay: `${Math.random() * 6}s`
        }} />
      ))}

      <span className="fish-swim text-2xl md:text-3xl" style={{ top: "10%", animationDuration: "14s" }}>🐟</span>
      <span className="fish-swim-reverse text-xl md:text-2xl" style={{ top: "60%", animationDuration: "16s", animationDelay: "3s" }}>🐠</span>

      <div className="relative z-10 text-center pt-8 sm:pt-10 pb-4 sm:pb-5 px-4">
        <div className="float-anim inline-block text-4xl sm:text-5xl mb-2 sm:mb-3">📋</div>
        <h1 className="text-2xl sm:text-3xl md:text-4xl font-black text-white drop-shadow-lg">
          Cara Penggunaan
        </h1>
        <p className="text-cyan-100 mt-2 text-sm sm:text-base">Baca panduan ini sebelum mulai belajar!</p>
        <div className="flex items-center justify-center gap-2 mt-3 sm:mt-4">
          <div className="h-1 w-12 sm:w-16 rounded-full bg-white/40"></div>
          <span className="text-xl sm:text-2xl">🌊</span>
          <div className="h-1 w-12 sm:w-16 rounded-full bg-white/40"></div>
        </div>
      </div>

      {/* Steps — 1 col on mobile, 2 col on md+ */}
      <div className="relative z-10 max-w-3xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-3">
        {steps.map((step, i) => (
          <div
            key={i}
            className="glass-card-white rounded-3xl p-3 sm:p-4 flex items-start gap-3 sm:gap-4 card-hover slide-in-up"
            style={{ animationDelay: `${i * 0.08}s` }}
          >
            <div
              className="text-xl sm:text-2xl flex-shrink-0 w-10 h-10 sm:w-12 sm:h-12 rounded-2xl flex items-center justify-center"
              style={{ background: "linear-gradient(135deg, #006994, #00bfff)", boxShadow: "0 4px 15px rgba(0,150,200,0.4)" }}
            >
              {step.icon}
            </div>
            <div>
              <h3 className="font-black text-gray-800 text-sm sm:text-base mb-0.5">{step.title}</h3>
              <p className="text-gray-600 text-xs sm:text-sm leading-relaxed">{step.desc}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="relative z-10 max-w-3xl mx-auto px-4 mt-4">
        <div className="rounded-3xl p-4 text-center" style={{ background: "rgba(255,255,255,0.15)", border: "2px solid rgba(255,255,255,0.4)" }}>
          <p className="text-white font-bold text-sm sm:text-base">
            🌊 Selamat belajar tentang <span className="text-cyan-200">Ekosistem Laut</span>!
          </p>
          <p className="text-white/80 text-xs sm:text-sm mt-1">
            Jelajahi keindahan laut dan pelajari cara menjaganya bersama-sama.
          </p>
        </div>
      </div>

      <div className="absolute bottom-20 left-0 right-0 flex items-end justify-around opacity-40">
        {["🪸","🌿","🪸","🌿","🪸","🌿"].map((c,i) => (
          <span key={i} className="coral-anim text-2xl sm:text-3xl" style={{ animationDelay: `${i * 0.3}s` }}>{c}</span>
        ))}
      </div>

      <NavButtons nextPath="/home" nextLabel="Selanjutnya" />
    </div>
  );
}
