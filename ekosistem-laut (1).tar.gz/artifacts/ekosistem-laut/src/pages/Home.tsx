import { useLocation } from "wouter";

const menuItems = [
  { icon: "📚", label: "CP & Tujuan", path: "/cp-tujuan", color: "from-blue-500 to-blue-700", bg: "rgba(59,130,246,0.15)", border: "rgba(59,130,246,0.4)", desc: "Capaian & Tujuan Pembelajaran" },
  { icon: "📖", label: "Materi", path: "/materi", color: "from-cyan-500 to-teal-600", bg: "rgba(6,182,212,0.15)", border: "rgba(6,182,212,0.4)", desc: "Pelajari Ekosistem Laut" },
  { icon: "🎥", label: "Video Edukasi", path: "/video", color: "from-purple-500 to-indigo-600", bg: "rgba(139,92,246,0.15)", border: "rgba(139,92,246,0.4)", desc: "Tonton Video Pembelajaran" },
  { icon: "❓", label: "Quiz", path: "/quiz", color: "from-orange-400 to-orange-600", bg: "rgba(249,115,22,0.15)", border: "rgba(249,115,22,0.4)", desc: "Uji Pengetahuanmu!" },
  { icon: "👤", label: "Profil", path: "/profil", color: "from-pink-500 to-rose-600", bg: "rgba(236,72,153,0.15)", border: "rgba(236,72,153,0.4)", desc: "Profil Pembuat Multimedia" },
];

export default function Home() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen ocean-gradient relative overflow-hidden pb-16">
      {/* Bubbles */}
      {Array.from({ length: 14 }).map((_, i) => (
        <div key={i} className="bubble" style={{
          left: `${Math.random() * 100}%`, bottom: 0,
          width: `${Math.random() * 22 + 8}px`, height: `${Math.random() * 22 + 8}px`,
          animationDuration: `${Math.random() * 8 + 5}s`, animationDelay: `${Math.random() * 7}s`
        }} />
      ))}

      {/* Fish */}
      <span className="fish-swim text-2xl md:text-3xl" style={{ top: "8%", animationDuration: "12s" }}>🐟</span>
      <span className="fish-swim text-xl md:text-2xl" style={{ top: "40%", animationDuration: "15s", animationDelay: "4s" }}>🐡</span>
      <span className="fish-swim-reverse text-2xl md:text-3xl" style={{ top: "25%", animationDuration: "13s", animationDelay: "2s" }}>🐠</span>

      {/* Header */}
      <div className="relative z-10 text-center pt-8 sm:pt-10 pb-6 sm:pb-8 px-4">
        <div className="float-anim inline-block text-4xl sm:text-5xl mb-2 sm:mb-3">🌊</div>
        <h1 className="text-2xl sm:text-3xl md:text-4xl font-black text-white drop-shadow-lg">
          Menu Utama
        </h1>
        <p className="text-cyan-100 text-base sm:text-lg font-semibold mt-1">Ekosistem Laut — IPAS Kelas V SD</p>

        <div
          className="inline-block mt-3 px-4 sm:px-6 py-2 rounded-full text-xs sm:text-sm font-semibold text-white/90"
          style={{ background: "rgba(255,255,255,0.15)", border: "1px solid rgba(255,255,255,0.3)" }}
        >
          🎓 Kurikulum Merdeka | Harmoni dalam Ekosistem
        </div>
      </div>

      {/* Menu Grid — 1 col on mobile, 2 col on md+ */}
      <div className="relative z-10 max-w-3xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
        {menuItems.map((item, i) => (
          <button
            key={i}
            onClick={() => navigate(item.path)}
            className={`w-full card-hover rounded-3xl p-4 sm:p-5 flex items-center gap-4 sm:gap-5 text-left transition-all duration-300${i === menuItems.length - 1 ? " md:col-span-2 md:max-w-sm md:mx-auto" : ""}`}
            style={{
              background: `linear-gradient(135deg, ${item.bg}, rgba(255,255,255,0.9))`,
              border: `2px solid ${item.border}`,
              boxShadow: "0 4px 20px rgba(0,100,200,0.15)",
              backdropFilter: "blur(10px)",
              animationDelay: `${i * 0.1}s`,
            }}
          >
            {/* Icon */}
            <div
              className={`w-12 h-12 sm:w-14 sm:h-14 md:w-16 md:h-16 rounded-2xl flex items-center justify-center text-2xl sm:text-3xl flex-shrink-0 bg-gradient-to-br ${item.color}`}
              style={{ boxShadow: "0 6px 20px rgba(0,0,0,0.2)" }}
            >
              {item.icon}
            </div>

            {/* Text */}
            <div className="flex-1 min-w-0">
              <h3 className="font-black text-gray-800 text-base sm:text-lg md:text-xl leading-tight">{item.label}</h3>
              <p className="text-gray-500 text-xs sm:text-sm mt-0.5 leading-snug">{item.desc}</p>
            </div>

            {/* Arrow */}
            <div
              className={`w-8 h-8 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center text-white bg-gradient-to-br ${item.color} flex-shrink-0 text-sm sm:text-base`}
            >
              →
            </div>
          </button>
        ))}
      </div>

      {/* Keluar — inline button below menu */}
      <div className="relative z-10 max-w-3xl mx-auto px-4 mt-4 flex justify-center">
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-1.5 px-6 py-3 rounded-2xl font-bold text-white shadow-lg transition-all duration-200 active:scale-95 text-sm"
          style={{ background: "linear-gradient(135deg, #ef4444, #dc2626)" }}
        >
          <span>🚪</span>
          <span>Keluar</span>
        </button>
      </div>

      {/* Bottom corals */}
      <div className="relative flex items-end justify-around mt-6 opacity-40">
        {["🪸","🌿","🪸","🌿","🪸","🌿","🪸","🌿"].map((c, i) => (
          <span key={i} className="coral-anim text-2xl sm:text-3xl" style={{ animationDelay: `${i * 0.3}s` }}>{c}</span>
        ))}
      </div>
    </div>
  );
}
