import { useLocation } from "wouter";
import { useEffect, useState } from "react";

export default function Landing() {
  const [, navigate] = useLocation();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setTimeout(() => setVisible(true), 100);
  }, []);

  return (
    <div className="relative min-h-screen overflow-hidden deep-ocean flex flex-col items-center justify-center">
      {/* Animated background layers */}
      <div className="absolute inset-0 z-0">
        {Array.from({ length: 30 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-white/20"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 80}%`,
              width: `${Math.random() * 4 + 2}px`,
              height: `${Math.random() * 4 + 2}px`,
              animationDelay: `${Math.random() * 3}s`,
              animation: `float-gentle ${3 + Math.random() * 2}s ease-in-out infinite`,
            }}
          />
        ))}
      </div>

      {/* Bubbles */}
      {Array.from({ length: 20 }).map((_, i) => (
        <div
          key={i}
          className="bubble"
          style={{
            left: `${Math.random() * 100}%`,
            bottom: 0,
            width: `${Math.random() * 25 + 8}px`,
            height: `${Math.random() * 25 + 8}px`,
            animationDuration: `${Math.random() * 8 + 5}s`,
            animationDelay: `${Math.random() * 8}s`,
          }}
        />
      ))}

      {/* Swimming fish */}
      <span className="fish-swim text-3xl md:text-4xl" style={{ top: "15%", animationDuration: "10s" }}>🐠</span>
      <span className="fish-swim text-2xl md:text-3xl" style={{ top: "55%", animationDuration: "14s", animationDelay: "3s" }}>🐡</span>
      <span className="fish-swim-reverse text-2xl md:text-3xl" style={{ top: "30%", animationDuration: "12s", animationDelay: "1s" }}>🐟</span>
      <span className="fish-swim-reverse text-3xl md:text-4xl" style={{ top: "70%", animationDuration: "16s", animationDelay: "5s" }}>🐠</span>
      <span className="turtle-anim" style={{ top: "80%", animationDelay: "2s", fontSize: "2.5rem" }}>🐢</span>

      {/* Light rays */}
      <div className="absolute top-0 left-1/4 w-32 h-full opacity-10"
        style={{ background: "linear-gradient(180deg, rgba(0,200,255,0.8) 0%, transparent 100%)", transform: "skewX(-10deg)" }}
      />
      <div className="absolute top-0 left-1/2 w-24 h-full opacity-8"
        style={{ background: "linear-gradient(180deg, rgba(100,230,255,0.6) 0%, transparent 80%)", transform: "skewX(5deg)" }}
      />
      <div className="absolute top-0 left-3/4 w-20 h-full opacity-10"
        style={{ background: "linear-gradient(180deg, rgba(0,200,255,0.7) 0%, transparent 70%)", transform: "skewX(-5deg)" }}
      />

      {/* Bottom corals */}
      <div className="absolute bottom-0 left-0 right-0 flex items-end justify-around">
        <span className="coral-anim text-3xl md:text-5xl opacity-70" style={{ animationDelay: "0s" }}>🪸</span>
        <span className="coral-anim text-2xl md:text-4xl opacity-60" style={{ animationDelay: "0.7s" }}>🌿</span>
        <span className="coral-anim text-4xl md:text-6xl opacity-70" style={{ animationDelay: "1.2s" }}>🪸</span>
        <span className="coral-anim text-2xl md:text-4xl opacity-60" style={{ animationDelay: "0.3s" }}>🌿</span>
        <span className="coral-anim text-3xl md:text-5xl opacity-70" style={{ animationDelay: "1.7s" }}>🪸</span>
        <span className="coral-anim text-2xl md:text-4xl opacity-60" style={{ animationDelay: "0.9s" }}>🌿</span>
        <span className="coral-anim text-4xl md:text-6xl opacity-70" style={{ animationDelay: "0.5s" }}>🪸</span>
        <span className="coral-anim text-2xl md:text-4xl opacity-60" style={{ animationDelay: "1.4s" }}>🌿</span>
      </div>

      {/* Main Content */}
      <div
        className="relative z-10 text-center px-4 sm:px-6 flex flex-col items-center w-full max-w-2xl mx-auto"
        style={{
          opacity: visible ? 1 : 0,
          transform: visible ? "translateY(0)" : "translateY(30px)",
          transition: "all 0.8s ease-out",
        }}
      >
        {/* Badge */}
        <div
          className="glass-card rounded-full px-4 sm:px-6 py-2 mb-5 text-cyan-200 font-semibold text-xs sm:text-sm tracking-wide flex items-center gap-1 flex-wrap justify-center"
          style={{ animationDelay: "0.2s" }}
        >
          📚 IPAS | Kelas V SD | Kurikulum Merdeka
        </div>

        {/* Title */}
        <div className="float-anim mb-2 w-full">
          <h1
            className="text-4xl sm:text-5xl md:text-7xl lg:text-8xl font-black text-white drop-shadow-2xl mb-2 leading-tight"
            style={{ textShadow: "0 0 40px rgba(0,200,255,0.8), 0 4px 20px rgba(0,0,0,0.5)" }}
          >
            🌊 EKOSISTEM
          </h1>
          <h1
            className="text-4xl sm:text-5xl md:text-7xl lg:text-8xl font-black drop-shadow-2xl leading-tight"
            style={{
              background: "linear-gradient(135deg, #00e5ff, #00bfff, #87ceeb)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              textShadow: "none",
              filter: "drop-shadow(0 0 20px rgba(0,200,255,0.6))",
            }}
          >
            LAUT
          </h1>
        </div>

        {/* Subtitle */}
        <div className="glass-card rounded-2xl px-5 sm:px-8 py-3 mb-2">
          <p className="text-lg sm:text-xl md:text-2xl font-bold text-cyan-100">
            Harmoni dalam Ekosistem
          </p>
        </div>

        <p className="text-white/70 text-xs sm:text-sm mb-6 sm:mb-8">
          Mata Pelajaran IPAS | Kelas V SD | Kurikulum Merdeka
        </p>

        {/* CTA Button */}
        <button
          onClick={() => navigate("/cara-penggunaan")}
          className="glow-btn relative text-white font-black text-lg sm:text-xl md:text-2xl px-8 sm:px-12 py-4 sm:py-5 rounded-3xl cursor-pointer transition-all duration-200 active:scale-95"
          style={{
            background: "linear-gradient(135deg, #00cc88, #00aaff, #0088ff)",
            backgroundSize: "200% 200%",
            animation: "glow-pulse 2s ease-in-out infinite, shimmer 3s linear infinite",
          }}
        >
          <span className="relative z-10 flex items-center gap-2 sm:gap-3">
            🎮 Mulai Belajar
          </span>
        </button>

        {/* Decorative bottom icons */}
        <div className="flex gap-4 sm:gap-8 mt-8 text-2xl sm:text-3xl opacity-70">
          <span className="float-anim" style={{ animationDelay: "0s" }}>🐠</span>
          <span className="float-anim" style={{ animationDelay: "0.5s" }}>🐙</span>
          <span className="float-anim" style={{ animationDelay: "1s" }}>🦈</span>
          <span className="float-anim" style={{ animationDelay: "1.5s" }}>🐚</span>
          <span className="float-anim" style={{ animationDelay: "2s" }}>🐬</span>
        </div>
      </div>

      {/* Wave at bottom */}
      <div className="absolute bottom-16 left-0 right-0 wave-container h-8">
        <svg className="wave-svg h-8" viewBox="0 0 1440 40" preserveAspectRatio="none" fill="rgba(0,180,255,0.3)">
          <path d="M0,20 C240,0 480,40 720,20 C960,0 1200,40 1440,20 L1440,40 L0,40 Z" />
        </svg>
      </div>
    </div>
  );
}
