import { useState } from "react";
import { useLocation } from "wouter";

const subBabs = [
  {
    id: 0,
    title: "Pengertian Ekosistem Laut",
    icon: "🌊",
    color: "from-blue-500 to-blue-700",
    content: [
      {
        type: "intro",
        text: "Ekosistem laut adalah kesatuan antara makhluk hidup (biotik) dan lingkungan tidak hidup (abiotik) di dalam laut yang saling berinteraksi dan bergantung satu sama lain.",
      },
      {
        type: "highlight",
        label: "Komponen Biotik",
        icon: "🐠",
        items: ["Ikan, paus, lumba-lumba, hiu", "Terumbu karang, ganggang laut, fitoplankton", "Kepiting, udang, bintang laut"],
      },
      {
        type: "highlight",
        label: "Komponen Abiotik",
        icon: "💧",
        items: ["Air laut (mengandung garam)", "Cahaya matahari yang menembus laut", "Suhu, arus, dan tekanan air"],
      },
      {
        type: "fact",
        text: "Laut menutupi lebih dari 70% permukaan bumi dan menjadi rumah bagi jutaan spesies makhluk hidup!",
      },
    ],
  },
  {
    id: 1,
    title: "Jenis-Jenis Biota Laut",
    icon: "🐠",
    color: "from-cyan-500 to-teal-600",
    content: [
      {
        type: "intro",
        text: "Biota laut adalah semua makhluk hidup yang hidup di dalam laut. Terdiri dari berbagai jenis hewan, tumbuhan, dan organisme yang luar biasa beragam!",
      },
      {
        type: "grid",
        items: [
          { icon: "🐋", name: "Mamalia Laut", ex: "Paus, Lumba-lumba, Dugong" },
          { icon: "🦈", name: "Ikan Laut", ex: "Hiu, Ikan Badut, Ikan Pari" },
          { icon: "🐙", name: "Moluska", ex: "Gurita, Cumi-cumi, Nautilus" },
          { icon: "🦀", name: "Krustasea", ex: "Kepiting, Udang, Lobster" },
          { icon: "🪸", name: "Terumbu Karang", ex: "Karang otak, Karang jamur" },
          { icon: "🌿", name: "Tumbuhan Laut", ex: "Ganggang, Lamun, Mangrove" },
          { icon: "⭐", name: "Echinodermata", ex: "Bintang laut, Bulu babi" },
          { icon: "🪼", name: "Ubur-ubur", ex: "Ubur-ubur biasa, Ubur-ubur kotak" },
        ],
      },
      {
        type: "fact",
        text: "Indonesia memiliki keanekaragaman hayati laut terbesar di dunia dengan lebih dari 37.000 km² terumbu karang!",
      },
    ],
  },
  {
    id: 2,
    title: "Rantai Makanan Laut",
    icon: "🦈",
    color: "from-indigo-500 to-purple-600",
    content: [
      {
        type: "intro",
        text: "Rantai makanan laut adalah urutan perpindahan energi dari satu makhluk hidup ke makhluk hidup lain melalui proses makan dan dimakan di ekosistem laut.",
      },
      {
        type: "chain",
        steps: [
          { icon: "☀️", label: "Matahari", desc: "Sumber energi utama" },
          { icon: "🌿", label: "Fitoplankton/Alga", desc: "Produsen (pembuat makanan)" },
          { icon: "🦐", label: "Zooplankton/Udang kecil", desc: "Konsumen tingkat 1" },
          { icon: "🐟", label: "Ikan kecil", desc: "Konsumen tingkat 2" },
          { icon: "🐠", label: "Ikan sedang", desc: "Konsumen tingkat 3" },
          { icon: "🦈", label: "Hiu/Predator besar", desc: "Konsumen puncak" },
        ],
      },
      {
        type: "highlight",
        label: "Peran dalam Rantai Makanan",
        icon: "♻️",
        items: [
          "Produsen: fitoplankton dan tumbuhan laut yang membuat makanan sendiri",
          "Konsumen: hewan yang memakan produsen atau hewan lain",
          "Pengurai: bakteri dan jamur yang mengurai sisa makhluk hidup",
        ],
      },
    ],
  },
  {
    id: 3,
    title: "Hubungan Antar Makhluk Hidup",
    icon: "🤝",
    color: "from-teal-500 to-green-600",
    content: [
      {
        type: "intro",
        text: "Makhluk hidup di laut tidak hidup sendiri. Mereka saling berhubungan satu sama lain melalui berbagai jenis interaksi yang unik!",
      },
      {
        type: "cards",
        items: [
          {
            icon: "🤝",
            title: "Simbiosis Mutualisme",
            color: "from-green-400 to-teal-500",
            desc: "Kedua pihak saling menguntungkan",
            ex: "Ikan badut 🐠 dan anemon laut — ikan badut terlindungi, anemon mendapat makanan",
          },
          {
            icon: "🦦",
            title: "Simbiosis Komensalisme",
            color: "from-blue-400 to-cyan-500",
            desc: "Satu pihak untung, satu tidak rugi/untung",
            ex: "Ikan remora menempel pada hiu 🦈 untuk mendapat sisa makanan tanpa merugikan hiu",
          },
          {
            icon: "🦠",
            title: "Simbiosis Parasitisme",
            color: "from-orange-400 to-red-500",
            desc: "Satu pihak untung, satu pihak rugi",
            ex: "Kutu laut 🦠 menempel pada ikan untuk mengisap darahnya",
          },
          {
            icon: "🦁",
            title: "Predasi",
            color: "from-purple-400 to-indigo-500",
            desc: "Hubungan pemangsa dan yang dimangsa",
            ex: "Hiu 🦈 memangsa ikan kecil untuk bertahan hidup",
          },
        ],
      },
      {
        type: "fact",
        text: "Setiap hubungan antar makhluk hidup di laut sangat penting untuk menjaga keseimbangan ekosistem!",
      },
    ],
  },
  {
    id: 4,
    title: "Menjaga Kelestarian Laut",
    icon: "🌍",
    color: "from-green-500 to-emerald-600",
    content: [
      {
        type: "intro",
        text: "Laut kita semakin terancam akibat ulah manusia. Kita semua harus bertanggung jawab menjaga kelestarian laut agar tetap sehat dan indah!",
      },
      {
        type: "two-col",
        left: {
          label: "❌ Ancaman bagi Laut",
          color: "from-red-100 to-orange-100",
          border: "#fca5a5",
          items: [
            "🗑️ Sampah plastik mencemari laut",
            "🎣 Penangkapan ikan berlebihan",
            "💥 Pengeboman dan pembiusan ikan",
            "⚓ Kerusakan terumbu karang",
            "🏭 Limbah industri dan rumah tangga",
            "🌡️ Perubahan iklim & pemanasan global",
          ],
        },
        right: {
          label: "✅ Cara Menjaga Laut",
          color: "from-green-100 to-teal-100",
          border: "#6ee7b7",
          items: [
            "🚯 Tidak membuang sampah ke laut",
            "♻️ Kurangi penggunaan plastik sekali pakai",
            "🐟 Dukung penangkapan ikan yang bertanggung jawab",
            "🪸 Jangan merusak terumbu karang",
            "🌊 Ikuti kegiatan bersih pantai",
            "📢 Ajak orang lain peduli terhadap laut",
          ],
        },
      },
      {
        type: "fact",
        text: "Setiap tahun, lebih dari 8 juta ton plastik masuk ke laut. Bersama, kita bisa mengubah kebiasaan buruk ini!",
      },
    ],
  },
];

function renderContent(content: typeof subBabs[0]["content"]) {
  return content.map((c, i) => {
    if (c.type === "intro") {
      return (
        <div key={i} className="rounded-2xl p-3 sm:p-4 mb-3 sm:mb-4" style={{ background: "linear-gradient(135deg, #e0f7ff, #f0fbff)", border: "2px solid #b3e5fc" }}>
          <p className="text-gray-700 leading-relaxed font-semibold text-xs sm:text-sm md:text-base">{c.text}</p>
        </div>
      );
    }
    if (c.type === "highlight" && c.items) {
      return (
        <div key={i} className="rounded-2xl p-3 sm:p-4 mb-3 sm:mb-4" style={{ background: "rgba(0,150,200,0.08)", border: "1.5px solid rgba(0,150,200,0.25)" }}>
          <div className="flex items-center gap-2 mb-2 sm:mb-3">
            <span className="text-lg sm:text-xl">{c.icon}</span>
            <h4 className="font-black text-gray-800 text-xs sm:text-sm md:text-base">{c.label}</h4>
          </div>
          <ul className="space-y-1.5 sm:space-y-2">
            {c.items.map((item, j) => (
              <li key={j} className="flex items-start gap-2 text-gray-700 text-xs sm:text-sm">
                <span className="text-cyan-600 font-black mt-0.5 flex-shrink-0">•</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>
      );
    }
    if (c.type === "fact") {
      return (
        <div key={i} className="rounded-2xl p-3 sm:p-4 mb-3 sm:mb-4 flex items-start gap-2 sm:gap-3"
          style={{ background: "linear-gradient(135deg, #fff9c4, #fffde7)", border: "2px solid #f9d71c" }}>
          <span className="text-xl sm:text-2xl flex-shrink-0">💡</span>
          <p className="text-gray-700 font-bold text-xs sm:text-sm">{c.text}</p>
        </div>
      );
    }
    if (c.type === "grid" && c.items) {
      return (
        <div key={i} className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3 sm:mb-4">
          {(c.items as any[]).map((item, j) => (
            <div key={j} className="rounded-xl p-2 sm:p-2.5 text-center"
              style={{ background: "linear-gradient(135deg, rgba(0,150,200,0.1), rgba(0,200,180,0.1))", border: "1.5px solid rgba(0,150,200,0.2)" }}>
              <div className="text-xl sm:text-2xl mb-1">{item.icon}</div>
              <div className="font-black text-gray-800 text-xs">{item.name}</div>
              <div className="text-gray-500 text-xs mt-0.5 leading-tight">{item.ex}</div>
            </div>
          ))}
        </div>
      );
    }
    if (c.type === "chain" && c.steps) {
      return (
        <div key={i} className="mb-3 sm:mb-4">
          <div className="flex flex-col gap-1.5 sm:grid sm:grid-cols-2 sm:gap-2">
            {(c.steps as any[]).map((step, j) => (
              <div key={j} className="flex items-center gap-2 sm:gap-3">
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center text-lg sm:text-xl flex-shrink-0"
                  style={{ background: "linear-gradient(135deg, #006994, #00aacc)" }}>{step.icon}</div>
                <div className="flex-1 rounded-xl p-2" style={{ background: "rgba(0,150,200,0.08)", border: "1.5px solid rgba(0,150,200,0.2)" }}>
                  <div className="font-black text-gray-800 text-xs sm:text-sm">{step.label}</div>
                  <div className="text-gray-500 text-xs">{step.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      );
    }
    if (c.type === "cards" && c.items) {
      return (
        <div key={i} className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3 mb-3 sm:mb-4">
          {(c.items as any[]).map((item, j) => (
            <div key={j} className="rounded-2xl p-3" style={{ background: "rgba(255,255,255,0.7)", border: "1.5px solid rgba(0,150,200,0.2)" }}>
              <div className="flex items-center gap-2 sm:gap-3 mb-2">
                <div className={`w-8 h-8 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center text-base sm:text-lg bg-gradient-to-br ${item.color}`}>{item.icon}</div>
                <div>
                  <div className="font-black text-gray-800 text-xs sm:text-sm">{item.title}</div>
                  <div className="text-xs text-gray-500">{item.desc}</div>
                </div>
              </div>
              <div className="rounded-xl p-2 text-xs text-gray-600"
                style={{ background: "rgba(0,150,200,0.06)", border: "1px solid rgba(0,150,200,0.15)" }}>
                📌 {item.ex}
              </div>
            </div>
          ))}
        </div>
      );
    }
    if (c.type === "two-col") {
      const col = c as any;
      return (
        <div key={i} className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3 mb-3 sm:mb-4">
          {[col.left, col.right].map((side: any, j) => (
            <div key={j} className={`rounded-2xl p-3 sm:p-4 bg-gradient-to-br ${side.color}`}
              style={{ border: `2px solid ${side.border}` }}>
              <h4 className="font-black text-gray-800 mb-2 sm:mb-3 text-xs sm:text-sm">{side.label}</h4>
              <ul className="space-y-1 sm:space-y-1.5">
                {side.items.map((it: string, k: number) => (
                  <li key={k} className="text-xs text-gray-700 leading-relaxed">{it}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      );
    }
    return null;
  });
}

export default function Materi() {
  const [activeTab, setActiveTab] = useState(0);
  const [, navigate] = useLocation();
  const current = subBabs[activeTab];
  const isLast = activeTab === subBabs.length - 1;
  const isFirst = activeTab === 0;

  return (
    <div className="min-h-screen pb-24 relative overflow-hidden"
      style={{ background: "linear-gradient(180deg, #003d6b 0%, #005c99 40%, #0088cc 100%)" }}>
      {Array.from({ length: 10 }).map((_, i) => (
        <div key={i} className="bubble" style={{
          left: `${Math.random() * 100}%`, bottom: 0,
          width: `${Math.random() * 18 + 6}px`, height: `${Math.random() * 18 + 6}px`,
          animationDuration: `${Math.random() * 8 + 5}s`, animationDelay: `${Math.random() * 6}s`
        }} />
      ))}
      <span className="fish-swim text-xl md:text-2xl" style={{ top: "8%", animationDuration: "15s" }}>🐠</span>
      <span className="fish-swim-reverse text-xl md:text-2xl" style={{ top: "40%", animationDuration: "17s", animationDelay: "5s" }}>🐟</span>

      {/* Header */}
      <div className="relative z-10 text-center pt-7 sm:pt-8 pb-2 sm:pb-3 px-4">
        <div className="float-anim inline-block text-3xl sm:text-4xl mb-1 sm:mb-2">📖</div>
        <h1 className="text-xl sm:text-2xl md:text-3xl font-black text-white drop-shadow-lg">Halaman Materi</h1>
        <p className="text-cyan-100 mt-1 font-semibold text-xs sm:text-sm">Ekosistem Laut</p>
      </div>

      {/* Tabs — scrollable */}
      <div className="relative z-10 px-3 mb-3">
        <div
          className="flex gap-1.5 sm:gap-2 overflow-x-auto pb-2"
          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        >
          {subBabs.map((s, i) => (
            <button
              key={i}
              onClick={() => setActiveTab(i)}
              className="flex-shrink-0 flex items-center gap-1 sm:gap-1.5 rounded-2xl font-bold transition-all duration-200"
              style={{
                padding: "5px 10px",
                fontSize: "0.7rem",
                whiteSpace: "nowrap",
                ...(activeTab === i
                  ? { background: "white", color: "#006994", boxShadow: "0 4px 15px rgba(0,0,0,0.2)" }
                  : { background: "rgba(255,255,255,0.2)", color: "white", border: "1px solid rgba(255,255,255,0.3)" })
              }}
            >
              <span>{s.icon}</span>
              <span>{i + 1}. {s.title.length > 14 ? s.title.substring(0, 14) + "…" : s.title}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-3xl mx-auto px-3">
        <div key={activeTab} className="glass-card-white rounded-3xl p-3 sm:p-4 md:p-6 slide-in-up">
          <div className="flex items-center gap-2 sm:gap-3 mb-3 sm:mb-4">
            <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-2xl flex items-center justify-center text-xl sm:text-2xl bg-gradient-to-br ${current.color} flex-shrink-0`}
              style={{ boxShadow: "0 6px 20px rgba(0,0,0,0.2)" }}>
              {current.icon}
            </div>
            <div>
              <div className="text-xs font-bold text-cyan-600 uppercase tracking-wide">Subbab {activeTab + 1} dari {subBabs.length}</div>
              <h2 className="text-sm sm:text-base md:text-lg font-black text-gray-800 leading-tight">{current.title}</h2>
            </div>
          </div>

          {renderContent(current.content)}

          {/* In-card prev/next */}
          <div className="flex justify-between items-center mt-3 sm:mt-4 pt-3 sm:pt-4 border-t border-gray-100 gap-2">
            <button
              onClick={() => setActiveTab(Math.max(0, activeTab - 1))}
              disabled={isFirst}
              className="flex items-center gap-1 sm:gap-1.5 px-3 py-2 rounded-xl font-bold text-xs sm:text-sm transition-all disabled:opacity-40 flex-1"
              style={{
                background: isFirst ? "#e5e7eb" : "linear-gradient(135deg, #006994, #00aacc)",
                color: isFirst ? "#9ca3af" : "white",
              }}
            >
              ← Sebelumnya
            </button>
            <span className="text-xs text-gray-400 font-semibold flex-shrink-0">{activeTab + 1}/{subBabs.length}</span>
            {!isLast ? (
              <button
                onClick={() => setActiveTab(activeTab + 1)}
                className="flex items-center gap-1 sm:gap-1.5 px-3 py-2 rounded-xl font-bold text-xs sm:text-sm transition-all flex-1 justify-end"
                style={{ background: "linear-gradient(135deg, #00aa77, #00cc88)", color: "white" }}
              >
                Berikutnya →
              </button>
            ) : (
              <div className="flex-1" />
            )}
          </div>
        </div>
      </div>

      <div className="absolute bottom-20 left-0 right-0 flex items-end justify-around opacity-40">
        {["🪸","🌿","🪸","🌿","🪸"].map((c,i) => (
          <span key={i} className="coral-anim text-2xl sm:text-3xl" style={{ animationDelay: `${i * 0.4}s` }}>{c}</span>
        ))}
      </div>

      {/* Bottom nav */}
      <div className="fixed bottom-0 left-0 right-0 z-50 px-4 pb-4 pt-2"
        style={{ background: "linear-gradient(to top, rgba(0,20,60,0.85) 0%, transparent 100%)" }}>
        <div className="flex justify-center gap-3 max-w-md mx-auto">
          <button
            onClick={() => navigate("/home")}
            className="flex items-center gap-1.5 px-4 sm:px-5 py-2.5 rounded-2xl font-bold text-white shadow-lg transition-all duration-200 active:scale-95 text-xs sm:text-sm"
            style={{ background: "linear-gradient(135deg, #00aacc, #007799)" }}
          >
            <span>🏠</span>
            <span>Kembali ke Menu Utama</span>
          </button>
        </div>
      </div>
    </div>
  );
}
