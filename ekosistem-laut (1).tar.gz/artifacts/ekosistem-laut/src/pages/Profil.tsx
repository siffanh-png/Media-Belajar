import NavButtons from "../components/NavButtons";

const pembuat = [
  {
    nama: "Sifa Nurul Hasanah",
    nim: "23834015",
    prodi: "Pendidikan Teknologi Informasi",
    univ: "Institut Pendidikan Indonesia Garut",
    avatar: "👩‍🎓",
    color: "from-blue-500 to-cyan-500",
    bgColor: "from-blue-50 to-cyan-50",
    borderColor: "#93c5fd",
  },
  {
    nama: "Putri Triani",
    nim: "23833032",
    prodi: "Pendidikan Teknologi Informasi",
    univ: "Institut Pendidikan Indonesia Garut",
    avatar: "👩‍💻",
    color: "from-purple-500 to-pink-500",
    bgColor: "from-purple-50 to-pink-50",
    borderColor: "#d8b4fe",
  },
];

export default function Profil() {
  return (
    <div className="min-h-screen pb-24 relative overflow-hidden"
      style={{ background: "linear-gradient(180deg, #0d0d2b 0%, #1a1a4e 30%, #003366 70%, #004d80 100%)" }}>
      {Array.from({ length: 12 }).map((_, i) => (
        <div key={i} className="bubble" style={{
          left: `${Math.random() * 100}%`, bottom: 0,
          width: `${Math.random() * 20 + 6}px`, height: `${Math.random() * 20 + 6}px`,
          animationDuration: `${Math.random() * 8 + 5}s`, animationDelay: `${Math.random() * 6}s`
        }} />
      ))}
      <span className="fish-swim text-xl md:text-2xl" style={{ top: "10%", animationDuration: "13s" }}>🐠</span>
      <span className="fish-swim-reverse text-xl md:text-2xl" style={{ top: "45%", animationDuration: "16s", animationDelay: "4s" }}>🐟</span>
      <span className="turtle-anim" style={{ top: "70%", animationDelay: "3s", fontSize: "2rem" }}>🐢</span>

      <div className="relative z-10 text-center pt-7 sm:pt-8 pb-3 sm:pb-4 px-4">
        <div className="float-anim inline-block text-3xl sm:text-4xl mb-2">👤</div>
        <h1 className="text-2xl sm:text-3xl md:text-4xl font-black text-white drop-shadow-lg">Profil Pembuat</h1>
        <p className="text-blue-200 mt-1 font-semibold text-xs sm:text-sm">Multimedia Pembelajaran Ekosistem Laut</p>
        <div className="flex items-center justify-center gap-2 mt-2 sm:mt-3">
          <div className="h-1 w-10 sm:w-12 rounded-full bg-white/30"></div>
          <span className="text-lg sm:text-xl">🌊</span>
          <div className="h-1 w-10 sm:w-12 rounded-full bg-white/30"></div>
        </div>
      </div>

      <div className="relative z-10 max-w-3xl mx-auto px-4 mb-4 sm:mb-5">
        <div className="rounded-3xl p-3 sm:p-4 text-center slide-in-up"
          style={{ background: "linear-gradient(135deg, rgba(0,180,255,0.2), rgba(100,50,255,0.2))", border: "2px solid rgba(255,255,255,0.3)" }}>
          <p className="text-white font-bold text-sm sm:text-base leading-relaxed">
            "Terima kasih telah menggunakan multimedia pembelajaran <span className="text-cyan-300">Ekosistem Laut</span>."
          </p>
          <p className="text-white/70 text-xs sm:text-sm mt-1">
            Semoga bermanfaat dan menambah pengetahuanmu tentang keindahan laut Indonesia! 🌊
          </p>
        </div>
      </div>

      <div className="relative z-10 max-w-3xl mx-auto px-4 space-y-3 sm:space-y-4">
        {/* Profile cards — 1 col on mobile, 2 col on md+ */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
          {pembuat.map((p, i) => (
            <div
              key={i}
              className="glass-card-white rounded-3xl p-4 sm:p-5 card-hover slide-in-up"
              style={{ animationDelay: `${i * 0.15}s` }}
            >
              <div className="flex items-start gap-3 sm:gap-4">
                <div className={`w-14 h-14 sm:w-16 sm:h-16 rounded-3xl flex items-center justify-center text-2xl sm:text-3xl bg-gradient-to-br ${p.color} flex-shrink-0`}
                  style={{ boxShadow: "0 8px 25px rgba(0,0,0,0.2)" }}>
                  {p.avatar}
                </div>
                <div className="flex-1 min-w-0">
                  <h2 className="text-base sm:text-lg font-black text-gray-800 mb-1 leading-tight">{p.nama}</h2>
                  <div className={`inline-block px-2 sm:px-2.5 py-1 rounded-full text-xs font-black mb-2 sm:mb-3 bg-gradient-to-r ${p.color} text-white`}>
                    NIM: {p.nim}
                  </div>
                  <div className="space-y-1.5 sm:space-y-2">
                    <div className={`rounded-xl p-2 sm:p-2.5 bg-gradient-to-r ${p.bgColor}`}
                      style={{ border: `1.5px solid ${p.borderColor}` }}>
                      <div className="text-xs text-gray-400 font-semibold uppercase tracking-wide">Program Studi</div>
                      <div className="text-xs sm:text-sm font-black text-gray-800 mt-0.5 leading-tight">{p.prodi}</div>
                    </div>
                    <div className={`rounded-xl p-2 sm:p-2.5 bg-gradient-to-r ${p.bgColor}`}
                      style={{ border: `1.5px solid ${p.borderColor}` }}>
                      <div className="text-xs text-gray-400 font-semibold uppercase tracking-wide">Universitas</div>
                      <div className="text-xs sm:text-sm font-black text-gray-800 mt-0.5 leading-tight">{p.univ}</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Info Multimedia */}
        <div className="glass-card-white rounded-3xl p-4 sm:p-5 slide-in-up" style={{ animationDelay: "0.3s" }}>
          <h3 className="font-black text-gray-800 text-sm sm:text-base mb-3 flex items-center gap-2">
            <span>📱</span> Tentang Multimedia Ini
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {[
              { icon: "📚", label: "Mata Pelajaran", value: "IPAS" },
              { icon: "🎓", label: "Jenjang", value: "Kelas V SD" },
              { icon: "📋", label: "Kurikulum", value: "Kurikulum Merdeka" },
              { icon: "🌊", label: "Materi", value: "Ekosistem Laut" },
              { icon: "🏫", label: "Institusi", value: "IPI Garut" },
              { icon: "📅", label: "Tahun", value: "2026" },
            ].map((item, i) => (
              <div key={i} className="rounded-xl p-2 sm:p-2.5"
                style={{ background: "linear-gradient(135deg, #e0f7ff, #f0fbff)", border: "1.5px solid #b3e5fc" }}>
                <div className="flex items-center gap-1 sm:gap-1.5 mb-0.5">
                  <span className="text-xs sm:text-sm">{item.icon}</span>
                  <div className="text-xs text-gray-400 font-semibold leading-tight">{item.label}</div>
                </div>
                <div className="text-xs sm:text-sm font-black text-gray-800 leading-tight">{item.value}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="rounded-3xl p-3 sm:p-4 text-center"
          style={{ background: "linear-gradient(135deg, rgba(0,50,100,0.6), rgba(0,100,150,0.6))", border: "1.5px solid rgba(255,255,255,0.2)" }}>
          <p className="text-white/80 text-xs sm:text-sm">© 2026 Multimedia Pembelajaran IPAS</p>
          <p className="text-cyan-300/80 text-xs mt-1">
            Pendidikan Teknologi Informasi | Institut Pendidikan Indonesia Garut
          </p>
          <div className="flex justify-center gap-2 sm:gap-3 mt-2 text-lg sm:text-xl">
            {["🌊","🐠","🪸","🐢","🌊"].map((e,i) => (
              <span key={i} className="float-anim" style={{ animationDelay: `${i * 0.5}s` }}>{e}</span>
            ))}
          </div>
        </div>
      </div>

      <div className="absolute bottom-20 left-0 right-0 flex items-end justify-around opacity-30">
        {["🪸","🌿","🪸","🌿","🪸"].map((c,i) => (
          <span key={i} className="coral-anim text-2xl sm:text-3xl" style={{ animationDelay: `${i * 0.4}s` }}>{c}</span>
        ))}
      </div>

      <NavButtons prevPath="/home" prevLabel="Kembali ke Menu" />
    </div>
  );
}
