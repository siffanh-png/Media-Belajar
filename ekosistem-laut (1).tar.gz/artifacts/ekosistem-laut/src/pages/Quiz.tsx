import { useState } from "react";
import NavButtons from "../components/NavButtons";

const questions = [
  {
    q: "Apa yang dimaksud dengan ekosistem laut?",
    options: [
      "Kumpulan ikan di laut",
      "Kesatuan makhluk hidup dan lingkungan tak hidup di laut yang saling berinteraksi",
      "Wilayah lautan yang sangat dalam",
      "Tempat tinggal hewan laut saja",
    ],
    correct: 1,
    explain: "Ekosistem laut adalah kesatuan antara makhluk hidup (biotik) dan lingkungan tidak hidup (abiotik) di dalam laut yang saling berinteraksi.",
  },
  {
    q: "Contoh simbiosis mutualisme di laut adalah...",
    options: [
      "Hiu memangsa ikan kecil",
      "Ikan badut dan anemon laut",
      "Kutu laut mengisap darah ikan",
      "Ikan remora menempel pada hiu",
    ],
    correct: 1,
    explain: "Ikan badut dan anemon laut adalah contoh simbiosis mutualisme karena keduanya saling diuntungkan.",
  },
  {
    q: "Dalam rantai makanan laut, fitoplankton berperan sebagai...",
    options: ["Konsumen tingkat 1", "Konsumen tingkat 2", "Produsen", "Pengurai"],
    correct: 2,
    explain: "Fitoplankton adalah produsen dalam rantai makanan laut karena dapat membuat makanan sendiri melalui fotosintesis.",
  },
  {
    q: "Manakah tindakan yang MERUSAK ekosistem laut?",
    options: [
      "Tidak membuang sampah ke laut",
      "Mengurangi plastik sekali pakai",
      "Penangkapan ikan dengan bom",
      "Ikut kegiatan bersih pantai",
    ],
    correct: 2,
    explain: "Penangkapan ikan dengan bom sangat merusak terumbu karang dan membunuh banyak biota laut yang tidak bersalah.",
  },
  {
    q: "Ikan remora yang menempel pada hiu merupakan contoh simbiosis...",
    options: ["Mutualisme", "Komensalisme", "Parasitisme", "Predasi"],
    correct: 1,
    explain: "Ikan remora mendapat sisa makanan dari hiu (untung), sedangkan hiu tidak dirugikan maupun diuntungkan → komensalisme.",
  },
];

export default function Quiz() {
  const [current, setCurrent] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);
  const [answers, setAnswers] = useState<(number | null)[]>(Array(questions.length).fill(null));

  const q = questions[current];

  function handleSelect(idx: number) {
    if (answered) return;
    setSelected(idx);
    setAnswered(true);
    const newAnswers = [...answers];
    newAnswers[current] = idx;
    setAnswers(newAnswers);
    if (idx === q.correct) setScore(s => s + 1);
  }

  function handleNext() {
    if (current < questions.length - 1) {
      setCurrent(c => c + 1);
      setSelected(answers[current + 1]);
      setAnswered(answers[current + 1] !== null);
    } else {
      setFinished(true);
    }
  }

  function handleReset() {
    setCurrent(0);
    setSelected(null);
    setAnswered(false);
    setScore(0);
    setFinished(false);
    setAnswers(Array(questions.length).fill(null));
  }

  const percentage = Math.round((score / questions.length) * 100);
  const emoji = percentage >= 80 ? "🏆" : percentage >= 60 ? "😊" : "💪";
  const message = percentage >= 80
    ? "Luar Biasa! Kamu sangat mengerti ekosistem laut!"
    : percentage >= 60
    ? "Bagus! Terus belajar ya!"
    : "Semangat! Pelajari lagi materinya ya!";

  if (finished) {
    return (
      <div className="min-h-screen pb-24 relative overflow-hidden flex flex-col items-center justify-center px-4"
        style={{ background: "linear-gradient(180deg, #004d33 0%, #006644 40%, #008855 70%, #00aa66 100%)" }}>
        {Array.from({ length: 14 }).map((_, i) => (
          <div key={i} className="bubble" style={{
            left: `${Math.random() * 100}%`, bottom: 0,
            width: `${Math.random() * 20 + 6}px`, height: `${Math.random() * 20 + 6}px`,
            animationDuration: `${Math.random() * 8 + 5}s`, animationDelay: `${Math.random() * 6}s`
          }} />
        ))}

        <div className="relative z-10 w-full max-w-md mx-auto">
          <div className="glass-card-white rounded-3xl p-5 sm:p-6 bounce-in">
            <div className="text-4xl sm:text-5xl text-center mb-2 sm:mb-3">{emoji}</div>
            <h2 className="text-xl sm:text-2xl font-black text-gray-800 mb-1 text-center">Quiz Selesai!</h2>
            <p className="text-gray-600 mb-4 sm:mb-5 text-center text-xs sm:text-sm">{message}</p>

            {/* Score */}
            <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full mx-auto mb-4 sm:mb-5 flex flex-col items-center justify-center"
              style={{ background: `conic-gradient(${percentage >= 80 ? "#00cc66" : percentage >= 60 ? "#f59e0b" : "#ef4444"} ${percentage * 3.6}deg, #e5e7eb 0deg)` }}>
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-white flex flex-col items-center justify-center">
                <div className="text-xl sm:text-2xl font-black" style={{ color: percentage >= 80 ? "#00cc66" : percentage >= 60 ? "#f59e0b" : "#ef4444" }}>
                  {score}
                </div>
                <div className="text-xs text-gray-400 font-semibold">dari {questions.length}</div>
              </div>
            </div>

            <div className="flex justify-center gap-2 sm:gap-3 mb-4 sm:mb-5 text-sm">
              <div className="rounded-xl px-3 sm:px-4 py-2 text-center" style={{ background: "#e0fdf4", border: "1.5px solid #6ee7b7" }}>
                <div className="font-black text-green-700 text-base sm:text-lg">{score}</div>
                <div className="text-green-600 text-xs">Benar</div>
              </div>
              <div className="rounded-xl px-3 sm:px-4 py-2 text-center" style={{ background: "#fef2f2", border: "1.5px solid #fca5a5" }}>
                <div className="font-black text-red-600 text-base sm:text-lg">{questions.length - score}</div>
                <div className="text-red-500 text-xs">Salah</div>
              </div>
              <div className="rounded-xl px-3 sm:px-4 py-2 text-center" style={{ background: "#eff6ff", border: "1.5px solid #93c5fd" }}>
                <div className="font-black text-blue-600 text-base sm:text-lg">{percentage}%</div>
                <div className="text-blue-500 text-xs">Nilai</div>
              </div>
            </div>

            {/* Review dots */}
            <div className="mb-4 sm:mb-5">
              <h3 className="font-black text-gray-700 mb-2 text-xs sm:text-sm">📋 Ringkasan:</h3>
              <div className="flex flex-wrap gap-2">
                {answers.map((ans, i) => (
                  <div key={i}
                    className="w-6 h-6 sm:w-7 sm:h-7 rounded-lg flex items-center justify-center text-xs font-black text-white"
                    style={{ background: ans === questions[i].correct ? "#22c55e" : "#ef4444" }}>
                    {i + 1}
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={handleReset}
              className="w-full py-3 sm:py-3.5 rounded-2xl font-black text-white text-sm sm:text-base transition-all active:scale-95"
              style={{ background: "linear-gradient(135deg, #006994, #00aacc)", boxShadow: "0 6px 20px rgba(0,150,200,0.4)" }}
            >
              🔄 Ulangi Quiz
            </button>
          </div>
        </div>

        <NavButtons prevPath="/home" prevLabel="Kembali ke Menu" />
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-24 relative overflow-hidden"
      style={{ background: "linear-gradient(180deg, #1a1a4e 0%, #2d2d7a 30%, #003d99 70%, #005588 100%)" }}>
      {Array.from({ length: 10 }).map((_, i) => (
        <div key={i} className="bubble" style={{
          left: `${Math.random() * 100}%`, bottom: 0,
          width: `${Math.random() * 16 + 6}px`, height: `${Math.random() * 16 + 6}px`,
          animationDuration: `${Math.random() * 8 + 5}s`, animationDelay: `${Math.random() * 6}s`
        }} />
      ))}
      <span className="fish-swim text-xl md:text-2xl" style={{ top: "10%", animationDuration: "14s" }}>🐠</span>
      <span className="fish-swim-reverse text-xl md:text-2xl" style={{ top: "50%", animationDuration: "17s", animationDelay: "5s" }}>🐟</span>

      <div className="relative z-10 text-center pt-7 sm:pt-8 pb-2 sm:pb-3 px-4">
        <div className="float-anim inline-block text-3xl sm:text-4xl mb-2">❓</div>
        <h1 className="text-2xl sm:text-3xl md:text-4xl font-black text-white drop-shadow-lg">Quiz Interaktif</h1>
        <p className="text-blue-200 mt-1 font-semibold text-xs sm:text-sm">Uji pengetahuanmu tentang Ekosistem Laut!</p>
      </div>

      {/* Progress */}
      <div className="relative z-10 max-w-2xl mx-auto px-4 mb-3">
        <div className="glass-card rounded-2xl p-2.5 sm:p-3">
          <div className="flex items-center justify-between mb-1.5 sm:mb-2">
            <span className="text-white text-xs sm:text-sm font-bold">Soal {current + 1}/{questions.length}</span>
            <span className="text-cyan-300 text-xs sm:text-sm font-bold">✅ {score} benar</span>
          </div>
          <div className="w-full h-2 sm:h-2.5 rounded-full bg-white/20 overflow-hidden">
            <div
              className="h-full rounded-full progress-bar-fill"
              style={{
                width: `${((current) / questions.length) * 100}%`,
                background: "linear-gradient(90deg, #00cc88, #00aaff)",
              }}
            />
          </div>
          <div className="flex gap-1 mt-2 justify-center flex-wrap">
            {questions.map((_, i) => (
              <div key={i}
                className="w-5 h-5 rounded-md flex items-center justify-center text-xs font-black"
                style={{
                  background: i === current
                    ? "white"
                    : answers[i] !== null
                    ? answers[i] === questions[i].correct ? "#22c55e" : "#ef4444"
                    : "rgba(255,255,255,0.2)",
                  color: i === current ? "#006994" : "white",
                  border: i === current ? "2px solid #00cc88" : "none",
                }}>
                {i + 1}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Question Card */}
      <div className="relative z-10 max-w-2xl mx-auto px-4">
        <div key={current} className="glass-card-white rounded-3xl p-4 sm:p-5 md:p-6 slide-in-up">
          <div className="mb-3 sm:mb-4">
            <div className="inline-block px-2.5 sm:px-3 py-1 rounded-full text-xs font-bold text-white mb-1.5 sm:mb-2"
              style={{ background: "linear-gradient(135deg, #006994, #00aacc)" }}>
              Soal {current + 1}
            </div>
            <h3 className="text-sm sm:text-base md:text-lg font-black text-gray-800 leading-relaxed">{q.q}</h3>
          </div>

          <div className="space-y-2 sm:space-y-2.5 mb-3 sm:mb-4">
            {q.options.map((opt, i) => {
              let style: React.CSSProperties = { background: "rgba(255,255,255,0.8)", border: "2px solid #e5e7eb" };
              let textClass = "text-gray-700";

              if (answered) {
                if (i === q.correct) {
                  style = { background: "linear-gradient(135deg, #22c55e, #16a34a)", border: "2px solid #16a34a" };
                  textClass = "text-white";
                } else if (i === selected && i !== q.correct) {
                  style = { background: "linear-gradient(135deg, #ef4444, #dc2626)", border: "2px solid #dc2626" };
                  textClass = "text-white";
                } else {
                  style = { background: "rgba(255,255,255,0.4)", border: "2px solid #e5e7eb", opacity: 0.6 };
                }
              } else if (selected === i) {
                style = { background: "linear-gradient(135deg, #e0f7ff, #b3e5fc)", border: "2px solid #0077aa" };
              }

              return (
                <button
                  key={i}
                  onClick={() => handleSelect(i)}
                  disabled={answered}
                  className={`w-full text-left p-2.5 sm:p-3 rounded-2xl flex items-center gap-2 sm:gap-3 font-semibold transition-all duration-200 ${!answered ? "active:scale-[0.99]" : ""} ${textClass}`}
                  style={style}
                >
                  <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-lg flex items-center justify-center text-xs font-black flex-shrink-0 text-white"
                    style={{ background: answered && (i === q.correct || (i === selected && i !== q.correct)) ? "rgba(255,255,255,0.3)" : "#006994" }}>
                    {String.fromCharCode(65 + i)}
                  </div>
                  <span className="flex-1 text-xs sm:text-sm leading-relaxed">{opt}</span>
                  {answered && i === q.correct && <span className="text-sm sm:text-base flex-shrink-0">✅</span>}
                  {answered && i === selected && i !== q.correct && <span className="text-sm sm:text-base flex-shrink-0">❌</span>}
                </button>
              );
            })}
          </div>

          {answered && (
            <div className="rounded-2xl p-2.5 sm:p-3 mb-3 sm:mb-4 fade-in"
              style={{ background: "linear-gradient(135deg, #e0f7ff, #f0fbff)", border: "2px solid #00aacc" }}>
              <div className="flex items-start gap-2">
                <span className="text-base sm:text-lg flex-shrink-0">💡</span>
                <div>
                  <div className="font-black text-gray-800 text-xs sm:text-sm mb-0.5">Penjelasan:</div>
                  <p className="text-gray-600 text-xs leading-relaxed">{q.explain}</p>
                </div>
              </div>
            </div>
          )}

          {answered && (
            <button
              onClick={handleNext}
              className="w-full py-3 sm:py-3.5 rounded-2xl font-black text-white text-sm sm:text-base transition-all active:scale-95 scale-in"
              style={{ background: "linear-gradient(135deg, #00aacc, #0077aa)", boxShadow: "0 6px 20px rgba(0,150,200,0.4)" }}
            >
              {current < questions.length - 1 ? "Soal Berikutnya →" : "Lihat Hasil Quiz 🏆"}
            </button>
          )}
        </div>
      </div>

      <div className="absolute bottom-20 left-0 right-0 flex items-end justify-around opacity-30">
        {["🪸","🌿","🪸","🌿","🪸"].map((c,i) => (
          <span key={i} className="coral-anim text-2xl sm:text-3xl" style={{ animationDelay: `${i * 0.4}s` }}>{c}</span>
        ))}
      </div>

      <NavButtons />
    </div>
  );
}
