import { useState } from "react";
import NavButtons from "../components/NavButtons";

const videos = [
  {
    id: 1,
    icon: "🌊",
    title: "Mengenal Ekosistem Laut",
    embed: "https://www.youtube.com/embed/hOl6Ot8wAok",
    desc: "Video pembelajaran tentang pengertian dan kondisi ekosistem laut.",
    color: "from-blue-500 to-blue-700",
  },
  {
    id: 2,
    icon: "🐠",
    title: "Jenis-Jenis Biota Laut",
    embed: "https://www.youtube.com/embed/kFoRaMDFVdg",
    desc: "Video pengenalan berbagai makhluk hidup yang ada di laut.",
    color: "from-cyan-500 to-teal-600",
  },
  {
    id: 3,
    icon: "🦈",
    title: "Rantai Makanan di Laut",
    embed: "https://www.youtube.com/embed/AChoNc5KGkU",
    desc: "Video penjelasan tentang alur rantai makanan dalam ekosistem laut.",
    color: "from-purple-500 to-indigo-600",
  },
  {
    id: 4,
    icon: "🌍",
    title: "Menjaga Kelestarian Laut",
    embed: "https://www.youtube.com/embed/2_rSsFw6FBg",
    desc: "Video edukasi tentang cara menjaga dan melestarikan ekosistem laut.",
    color: "from-green-500 to-emerald-600",
  },
];

export default function VideoEdukasi() {
  const [selected, setSelected] = useState(0);

  return (
    <div className="min-h-screen pb-24 relative overflow-hidden"
      style={{ background: "linear-gradient(180deg, #1a0050 0%, #2d0080 30%, #003d99 70%, #006994 100%)" }}>
      {Array.from({ length: 12 }).map((_, i) => (
        <div key={i} className="bubble" style={{
          left: `${Math.random() * 100}%`, bottom: 0,
          width: `${Math.random() * 18 + 6}px`, height: `${Math.random() * 18 + 6}px`,
          animationDuration: `${Math.random() * 8 + 5}s`, animationDelay: `${Math.random() * 6}s`
        }} />
      ))}
      <span className="fish-swim text-xl md:text-2xl" style={{ top: "12%", animationDuration: "13s" }}>🐟</span>
      <span className="fish-swim-reverse text-xl md:text-2xl" style={{ top: "35%", animationDuration: "16s", animationDelay: "4s" }}>🐠</span>

      <div className="relative z-10 text-center pt-7 sm:pt-8 pb-3 sm:pb-4 px-4">
        <div className="float-anim inline-block text-3xl sm:text-4xl mb-2">🎥</div>
        <h1 className="text-2xl sm:text-3xl md:text-4xl font-black text-white drop-shadow-lg">Video Edukasi</h1>
        <p className="text-purple-200 mt-1 font-semibold text-xs sm:text-sm">Tonton video pembelajaran seru!</p>
      </div>

      {/* On lg+: side-by-side player & list; below lg: stacked */}
      <div className="relative z-10 max-w-5xl mx-auto px-3 flex flex-col lg:flex-row gap-4">

        {/* Video Player */}
        <div className="flex-1 min-w-0">
          <div className="glass-card-white rounded-3xl overflow-hidden shadow-2xl slide-in-up">
            <div className="p-3 pb-2 flex items-center gap-3">
              <div className={`w-8 h-8 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center text-lg sm:text-xl bg-gradient-to-br ${videos[selected].color} flex-shrink-0`}>
                {videos[selected].icon}
              </div>
              <div className="min-w-0">
                <div className="font-black text-gray-800 text-sm truncate">{videos[selected].title}</div>
                <div className="text-xs text-gray-500">Video {selected + 1} dari {videos.length}</div>
              </div>
            </div>

            <div className="relative w-full" style={{ paddingBottom: "56.25%" }}>
              <iframe
                key={selected}
                className="absolute top-0 left-0 w-full h-full"
                src={videos[selected].embed}
                title={videos[selected].title}
                frameBorder="0"
                allowFullScreen
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              />
            </div>
            <div className="p-3 pt-2">
              <p className="text-gray-600 text-xs leading-relaxed">{videos[selected].desc}</p>
            </div>
          </div>
        </div>

        {/* Video List */}
        <div className="lg:w-64 xl:w-72 flex-shrink-0">
          <h3 className="text-white font-black text-sm sm:text-base mb-2 px-1">📋 Daftar Video</h3>
          <div className="grid grid-cols-1 gap-2">
            {videos.map((v, i) => (
              <button
                key={v.id}
                onClick={() => setSelected(i)}
                className="text-left rounded-2xl p-2.5 sm:p-3 flex items-center gap-3 transition-all duration-200 active:scale-[0.99]"
                style={selected === i
                  ? { background: "rgba(255,255,255,0.95)", border: "2px solid #00aacc", boxShadow: "0 8px 25px rgba(0,170,204,0.3)" }
                  : { background: "rgba(255,255,255,0.15)", border: "1.5px solid rgba(255,255,255,0.25)" }
                }
              >
                <div className={`w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center text-lg sm:text-xl flex-shrink-0 bg-gradient-to-br ${v.color}`}>
                  {v.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className={`font-black text-xs sm:text-sm truncate ${selected === i ? "text-gray-800" : "text-white"}`}>{v.title}</div>
                  <div className={`text-xs mt-0.5 line-clamp-1 ${selected === i ? "text-gray-500" : "text-white/60"}`}>{v.desc}</div>
                </div>
                {selected === i && (
                  <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-lg flex items-center justify-center text-white text-xs flex-shrink-0" style={{ background: "#00aacc" }}>▶</div>
                )}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="absolute bottom-20 left-0 right-0 flex items-end justify-around opacity-30">
        {["🪸","🌿","🪸","🌿","🪸"].map((c,i) => (
          <span key={i} className="coral-anim text-2xl sm:text-3xl" style={{ animationDelay: `${i * 0.4}s` }}>{c}</span>
        ))}
      </div>

      <NavButtons prevPath="/home" prevLabel="Kembali ke Menu" />
    </div>
  );
}
